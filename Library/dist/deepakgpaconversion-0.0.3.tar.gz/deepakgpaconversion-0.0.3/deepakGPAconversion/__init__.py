def gpa_to_percentage(gpa):
    return gpa * 9.5  # Assuming a scale where GPA * 9.5 gives the percentage.
